Intro
=====

This demo project shows how to send and receive messages to an ActiveMQ queue in JBoss WildFly 10.
To prepare the environment and then run the demo, you need to follow the 4 steps in this doc:
  1 - Start WildFly "full" profile (i.e. with the ActiveMQ service running).
  2 - Create a JMS guest user on WildFly 10.
  3 - Create a queue and give it a JNDI name.
  4 - Run the demo code (i.e. to send and receive messages to the queue).


1. Start WildFly "full" profile
===============================
- First set the JAVA_HOME environment variable to your JDK folder.

- Open a Command Prompt window as an Administrator and go to this folder:
      C:\wildfly-10.0.0.Final\bin 

- Run the following batch file, to start WildFly in "full" profile:
      standalone.bat -c standalone-full.xml

- Keep the Command Prompt window open until you've finished this demo.


2. Create a JMS guest user on WildFly 10
========================================
- Open another Command Prompt window as an Administrator and go to the same folder as before:
      C:\wildfly-10.0.0.Final\bin 

- Run the following batch file, to add a user:
      add-user.bat
  
  You will be asked a series of questions. Answer them as follows...
      What type of user do you wish to add?  Choose (b), i.e. application user.
      Username: jmsuser     (for example)
      Password: password-1  (for example)
      What groups do you want this user to belong to? guest
      About to add user 'jmsuser' for realm 'ApplicationRealm'. Is this correct yes/no?  yes
      Is this new user going to be used for one AS process ... etc ... ? yes


3. Create a queue and give it a JNDI name
=========================================
- Continue in the Command Prompt window, in the same folder as before:
      C:\wildfly-10.0.0.Final\bin 

- Run the following batch file, to create a queue in ActiveMQ:
      jboss-cli.bat -c
  The following prompt will appear:
      [standalone@localhost:9990 /]

- Type the following at the prompt, to create a queue named TestQ and a JBoss-friendly JNDI name:
      /subsystem=messaging-activemq/server=default/jms-queue=TestQ/:add(entries=["java:/jboss/exported/jms/queue/TestQ"])
  It should display the following response:
      {"outcome" => "success"}
   
- Type the following at the prompt:
      :reload
  It should display the following response:
      {
        "outcome" => "success",
        "result" => undefined
      }


4. Run the demo code
====================
- Open the DemoMessaging project in Eclipse. 
  This is a Java EE Application Client project, i.e. it has access to JNDI names.

- Take a look at the following classes:
      MyConstannts.java - Defines useful constants (JNDI names, username/password, server URL).
      Sender.java       - Sends messages to the test queue.
      Receiver.java     - Receives messages asynchronously from the test queue.
      Main.java         - Application entry point.

- Run Main.java. 
  This should send 10 messages, then receive them.
