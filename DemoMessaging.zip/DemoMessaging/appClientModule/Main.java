
public class Main {

	public static void main(String[] args) throws Exception {
		
		Sender sender = new Sender();
		sender.doDemo();
		
		Receiver receiver = new Receiver();
		receiver.doDemo();
	}
}
