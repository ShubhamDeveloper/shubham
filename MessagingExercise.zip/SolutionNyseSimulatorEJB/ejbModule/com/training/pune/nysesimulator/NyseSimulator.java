package com.training.pune.nysesimulator;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.InitialContext;

@Startup
@Singleton
public class NyseSimulator {

	Map<String, Double> stocks = new HashMap<>();
	
	public NyseSimulator() {
		stocks.put("BBY",32.630001);
		stocks.put("BAC",15.2);
		stocks.put("FCX",11.75);
		stocks.put("AUY",5.15);
		stocks.put("CHK",5.84);
		stocks.put("WLL",7.77);
		stocks.put("GE",31.17);
		stocks.put("KGC",4.82);
		stocks.put("VRX",29.809999);
		stocks.put("VALE",5.86);
		stocks.put("S",5.9);
		stocks.put("PBR",9.16);
		stocks.put("IAG",4.58);
		stocks.put("EMC",28.59);
		stocks.put("F",12.35);
		stocks.put("MRO",16.200001);
		stocks.put("JCI",45.0);
		stocks.put("X",20.4);
		stocks.put("GGB",3.12);
		stocks.put("PFE",34.799999);
		stocks.put("TOL",28.84);
		stocks.put("BBD",9.05);
		stocks.put("WFT",5.76);
		stocks.put("MT",6.29);
		stocks.put("NOK",5.65);
		stocks.put("WFC",48.639999);
		stocks.put("ABX",20.17);
		stocks.put("C",46.419998);
		stocks.put("HL",6.6);
		stocks.put("CLF",6.01);
		stocks.put("T",40.919998);
		stocks.put("ECA",9.94);
		stocks.put("CX",8.56);
		stocks.put("WMB",27.24);
		stocks.put("HPQ",14.36);
		stocks.put("KR",32.639999);
		stocks.put("JCP",10.2);
		stocks.put("DNR",3.05);
		stocks.put("AKS",4.62);
		stocks.put("KEY",12.21);
		stocks.put("AA",10.2);
		stocks.put("RIG",10.36);
		stocks.put("RF",9.63);
		stocks.put("POT",16.049999);
		stocks.put("MON",104.269997);
		stocks.put("LMT",254.369995);
		stocks.put("CF",23.030001);
		stocks.put("SWN",13.62);
		stocks.put("SNY",39.27);
		stocks.put("GLW",22.65);
		stocks.put("JPM",65.75);
		stocks.put("DAL",36.529999);
		stocks.put("LYG",2.96);
		stocks.put("GM",31.790001);
		stocks.put("V",80.339996);
		stocks.put("NBR",9.96);
		stocks.put("NKE",58.82);
		stocks.put("PHM",21.17);
		stocks.put("WMT",73.059998);
		stocks.put("HAL",46.18);
		stocks.put("AZN",33.560001);
		stocks.put("DHI",31.879999);
		stocks.put("BCS",8.42);
		stocks.put("TCK",15.4);
		stocks.put("GNW",3.89);
		stocks.put("MS",30.440001);
		stocks.put("NE",6.13);
		stocks.put("DVN",43.650002);
		stocks.put("VZ",52.580002);
		stocks.put("GG",18.01);
		stocks.put("CIG",2.84);
		stocks.put("ESV",8.53);
		stocks.put("AEO",19.040001);
		stocks.put("SJM",154.830002);
		stocks.put("TYC",44.790001);
		stocks.put("BP",33.830002);

	}
	
	private String generateRandomPrice() {
		//Pick a random stock
		Random random = new Random();
		List<String> keys = new ArrayList<String>(stocks.keySet());
		String randomStock = keys.get( random.nextInt(keys.size()) );

		//adjust its price randomly
		double randomPercentChange = (Math.random()-1)*5;
		Double oldPrice = stocks.get(randomStock);
		Double newPrice = oldPrice + (oldPrice*randomPercentChange)/100;
		
		//Set the new price
		stocks.put(randomStock, newPrice);
		
		//return the new price
		return randomStock+":"+newPrice;
	}

	private long generateRandomSleepTime() {
		//return a random number in the range 0 to 5000 (millisecs)
		Random random = new Random();
		return random.nextInt(5000);
	}
	
	@PostConstruct
	public void sendPrices() {
		try { 
			//Create and start JMS connection
			InitialContext ctx = new InitialContext();
			TopicConnectionFactory f = (TopicConnectionFactory) ctx.lookup("java:/ConnectionFactory");
			TopicConnection con = f.createTopicConnection();
			con.start();
			// 2) create topic session
			TopicSession ses = con.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
			// 3) get the Topic object
			Topic t = (Topic) ctx.lookup("java:/NyseSimulator");
			// 4)create TopicSender object
			TopicPublisher sender = ses.createPublisher(t);
			// 5) create TextMessage object
			TextMessage msg = ses.createTextMessage();

			while (true) {
				String randomPrice = generateRandomPrice();;
				msg.setText(randomPrice);
				// 7) send message
				sender.send(msg);
				System.out.println("Stock Price published --> "+randomPrice);
				//Pause for a random amount of time
				Thread.sleep(generateRandomSleepTime());
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
