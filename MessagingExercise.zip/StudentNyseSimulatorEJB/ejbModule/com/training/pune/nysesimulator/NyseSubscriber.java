package com.training.pune.nysesimulator;

import java.io.IOException;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.Init;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "messagingType", propertyValue = "javax.jms.MessageListener"),
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "FILL ME IN"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "FILL ME IN"),
		@ActivationConfigProperty(propertyName = "ConnectionFactoryName", propertyValue = "FILL ME IN"),
})
/**
 * INSTRUCTIONS:
 * 
 * 1. Make me a message driven bean and implement my method(s) appropriately. 
 * 2. Fill in the correct values for the ActivationConfigProperty values to allow this 
 *    message driven bean to listen on the correct ConnectionFactory and Topic.
 * 3. Parse the stock information received in each message.
 * 4. Present the stock name and price to the end user 
 * 
 * The aim is to listen to prices that are published on the "NyseSimulator" topic
 * 
 * which you configured in the setup part of this exercise and which the NyseSimulator is publishing prices on
 * Once you have received the message, parse it and display the stock name and the price received to the user. 
 *
 * Note the NyseSubscriber class should just start publishing prices once you start Wildfly. You do not need to do anything
 * to get it to start publishing prices.
 *
 * @author Niall
 *
 */
public class NyseSubscriber {
	

}